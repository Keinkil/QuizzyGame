package controller;

import java.util.ArrayList;

import qAndA.Question;

public class QuestionController {
	private ArrayList<Question> questions = new ArrayList<Question>();
}
