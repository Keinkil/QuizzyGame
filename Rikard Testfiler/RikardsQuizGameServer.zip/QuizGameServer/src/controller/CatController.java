package controller;

import java.util.ArrayList;

import category.Category;

public class CatController {

	private ArrayList<Category> category = new ArrayList<Category>();
	
	public CatController() {
		category.add(new Category("Trigonometri"));
		category.add(new Category("Geometri"));
		category.add(new Category("Algebra"));
	}

	public int catExists(String cat) {
		for (Category c : category) {
			if (c.getName().equals(cat)) {
				return category.indexOf(c);
			}
		}
		return -1;

	}

	public ArrayList<String> getCategoryNames() {
		ArrayList<String> catNames = new ArrayList<String>();
		for (Category c : category) {
			catNames.add(c.getName());
		}
		return catNames;
	}

	public boolean renameCategory(String cat, String name) {
		int index = catExists(cat);
		if (index != -1) {
			Category reCat = category.get(index);
			System.out.println("Renamed category " + cat + " to " + name);
			reCat.setName(name);
			return true;
		}
		System.out.println("No such category");
		return false;
	}
	
	public int removeCategory(String cat){
		for(int i = 0; i < category.size(); i++){
			
			if(category.get(i).getName().equals(cat)){
				System.out.println("DELETED category : " + cat);
				category.remove(i);
				return 1;
				
			}
			
		}
		System.out.println("No such category");
		return -1;
	}
	
	public int addCat(String cat){
		if(catExists(cat) < 0){
		category.add(new Category(cat));
		return 1;
	}
		
		return -1;

}
	
}
